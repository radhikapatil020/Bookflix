<?php
    $conn = new mysqli('localhost','root','','bookflixdb') or die('Connection Failed'.mysqli_error($conn));

?>